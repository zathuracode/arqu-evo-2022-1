package com.vobi.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankBalanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
